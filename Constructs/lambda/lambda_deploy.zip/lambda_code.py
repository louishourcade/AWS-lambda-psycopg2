import psycopg2


def handler(event, context):
    """Function that checks whether psycopg2 is succesfully imported or not"""
    print(f"psycopg2 successfully imported")

    return {"Status": "SUCCESS"}


# if __name__ == "__main__":
#     handler(None, None)
